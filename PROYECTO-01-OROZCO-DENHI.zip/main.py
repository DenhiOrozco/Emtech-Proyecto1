from lifestore_file import lifestore_sales, lifestore_products, lifestore_searches

user_admin=[["Denhi", 123], ["Mariana", 123], ["Sofia", 123]]
user_input= input("Ingresa tu usuario: ")
password_input= input("Ingresa tu password: ")
pass_num=int(password_input)
intentos=0 #bandera
admin=0 #bandera
""""
INICIO DE SESIÓN
"""
#Itera en la variable usuario relacionada con user_admin, de acuerdo a la cantidad de valores definidos en la variable user_admin. Verifica que el indice 0, usuario y el indice 1 password, correspondan con user_admin. En caso de ser TRUE, muestra un mensaje y comienza con la siguiente sección. En caso contrario, itera 2 veces más.

for usuario in user_admin: 
  if usuario[0] ==user_input and usuario [1]==pass_num and intentos<3:
   admin=1 
   if admin==1:
     print ("Tú password es correcto.")
     break
   else:  
    admin=0
    intentos +=1
    nuevo_usuario= user_input
    nuevo_password=pass_num
  else: 
   continue     

"""
INGRESO AL SISTEMA
"""   
#En caso de ser administrador la variable admin estará definida como 1, caso contrario, mostrará al usuario que la contraseña no es correcta y lo sacará del sistema. 

if admin ==1:
  print("Bienvenido " +user_input)



  """
  Menus
  """
  #De acuerdo a la opción seleccionada, se muestran ventas, búsquedas, ingresos, etc.
  print("¿Qué deseas hacer?\n a- Consultar productos con mayores ventas \n b- Consultar productos con más búsquedas\n c- Consultar ventas y búsquedas por categoría\n d- Consultar ingresos y ventas\n e- Consultar productos por reseña\n")
   
  opciones=0

  """
  Mayores ventas
  """
  while opciones ==0:
    opciones=input("Teclea la opción deseada: ")

    if opciones== "a":
      
      opciones_ventas=input("Deseas considerar las devoluciones? Teclea Yes o No:")
      if opciones_ventas =="Yes":
        """
        #50 Productos más vendidos considerando devoluciones
        """
        contador_devoluciones = 0 #bandera para contar número de veces que se vende un producto

        lista_ventas_devoluciones = [] # lista en blanco [ventas (veces vendido), nombre, id]

        #usa el id de producto como llave entre las dos tablas (lista de producto y lista de ventas) y si son iguales, cuenta el producto.

        for nombre in lifestore_products:
          for ventas in lifestore_sales:
            if nombre [0]== ventas [1] and ventas[4] ==0:
              contador_devoluciones +=1 #si el id es el mismo y las ventas no fueron devueltas, las cuenta
          agregar_producto= [contador_devoluciones, nombre[1], nombre [0]] #define como será el orden en el que se agregará el producto
          lista_ventas_devoluciones.append(agregar_producto) #agrega el producto a la lista
          contador_devoluciones=0 #resetea el contador 


          lista_ordenada= sorted(lista_ventas_devoluciones,reverse=True)
        for cincuenta in range(0,50):

          print("Producto: \n", lista_ordenada[cincuenta][1],"\n", "Con:\n",lista_ordenada[cincuenta][0], "productos vendidos \n")

          #print(lista_ordenada)  Esta linea es para exportar datos a Excel

    

      

          """
          #50 Productos más vendidos
          """
      elif opciones_ventas =="No":
        contador = 0 #bandera para contar número de veces que se vende un producto

        lista_ventas = [] # lista en blanco [ventas (veces vendido), nombre, id]

      #usa el id de producto como llave entre las dos tablas (lista de producto y lista de ventas) y si son iguales, cuenta el producto.

        for nombre in lifestore_products:
          for ventas in lifestore_sales:
            if nombre [0]== ventas [1]:
              contador +=1
          agregar_producto= [contador, nombre[1], nombre [0]] #define como será el orden en el que se agregará el producto
          lista_ventas.append(agregar_producto) #agrega el producto a la lista
          contador=0 #resetea el contador 


          lista_ordenada= sorted(lista_ventas,reverse=True)

        for cincuenta in range(0,50):

          print("Producto: \n", lista_ordenada[cincuenta][1],"\n", "Con:\n",lista_ordenada[cincuenta][0], "productos vendidos \n")
        else:
          break
        #lista_ordenada= sorted(lista_ventas,reverse=True)

      """
      Mayores búsquedas
      """
    elif opciones== "b":
      contador_busquedas = 0 #bandera para contar número de veces que se busca un producto
      lista_busquedas = [] # lista en blanco [busquedas (veces buscado), nombre, id]
      #usa el id de producto como llave entre las dos tablas (lista de producto y lista de busquedas) y si son iguales, cuenta el producto.
      for nombre in lifestore_products:
        for busquedas in lifestore_searches:
          if nombre [0]== busquedas [1]:
            contador_busquedas +=1 #si el id es el mismo y cuenta las busquedas
        agregar_producto_busquedas= [contador_busquedas, nombre[1], nombre [0]] #define como será el orden en el que se agregará el producto
        lista_busquedas.append(agregar_producto_busquedas) #agrega el producto a la lista
        contador_busquedas=0 #resetea el contador 
        lista_ordenada_busquedas= sorted(lista_busquedas,reverse=True)
      for cien in range(0,100):

        print("Producto: \n",lista_ordenada_busquedas[cien][1],"\n", "Con:\n",lista_ordenada_busquedas[cien][0], "productos buscados \n")
      else:
        break
    elif opciones== "c":
      seleccion_categorias=input("¿Deseas ver búsquedas 'B' o ventas 'V' por categoría?\n Responde B o V: ")
      if seleccion_categorias == "B" or "b":
        #Se crean listas vacias para poder dividir en categorías los productos posteriormente
        cat_procesadores=[]
        cat_tarjetsvideo=[]
        cat_tarjetasmadre=[]
        cat_discosduros=[]
        cat_memoriasusb=[]
        cat_pantallas=[]
        cat_bocinas=[]
        cat_audifonos=[]

        contador_busquedas = 0 #bandera para contar número de veces que se busca un producto
        lista_busquedas_categoria = [] # lista en blanco [busquedas (veces buscado), is, nombre y categoria]
        #usa el id de producto como llave entre las dos tablas (lista de producto y lista de busquedas) y si son iguales, cuenta el producto.Posteriormente divide en categorías.
        for nombre in lifestore_products:
          for busquedas in lifestore_searches:
            if nombre [0]== busquedas [1]:
              contador_busquedas +=1 #si el id es el mismo y cuenta las busquedas
          agregar_producto_busquedas= [contador_busquedas, nombre[0], nombre [1], nombre[3]] #define como será el orden en el que se agregará el producto
          lista_busquedas_categoria.append(agregar_producto_busquedas) #busquedas, id, nombre y categoria
          contador_busquedas=0 #resetea el contador 
          lista_ordenada_categoria= sorted(lista_busquedas_categoria,reverse=True)
        #divide las búsquedas por categoria con un condicional sobre el campo de la categoria en caso de que sea afirmativo, crea una nueva lista
        for categoria in lista_ordenada_categoria:
          if categoria [3]== "procesadores":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_procesadores.append(agregar_categoria)
          elif categoria [3]== "tarjetas de video":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_tarjetsvideo.append(agregar_categoria)
          elif categoria [3]== "tarjetas madre":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_tarjetasmadre.append(agregar_categoria)
          elif categoria [3]== "discos duros":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_discosduros.append(agregar_categoria)
          elif categoria [3]== "memorias usb":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_memoriasusb.append(agregar_categoria)
          elif categoria [3]== "pantallas":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_pantallas.append(agregar_categoria)
          elif categoria [3]== "bocinas":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_bocinas.append(agregar_categoria)
          elif categoria [3]== "audifonos":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_audifonos.append(agregar_categoria)
          else:
            break
        print("Categoría: audífonos")
        print(cat_audifonos[0:20],"\n")
        print("Categoría:bocinas")
        print(cat_bocinas[0:20],"\n")
        print("Categoría: discos duros")
        print(cat_discosduros[0:20],"\n")
        print("Categoría: memorias USB")
        print(cat_memoriasusb[0:20],"\n")
        print("Categoría: pantallas")
        print(cat_pantallas[0:20],"\n")
        print("Categoría: procesadores")
        print(cat_procesadores[0:20],"\n")
        print("Categoría: tarjetas madre")
        print(cat_tarjetasmadre[0:20],"\n")
        print("Categoría: tarjetas de video")
        print(cat_tarjetsvideo[0:20],"\n") 
      if seleccion_categorias == "V" or "v":
        #Se crean listas vacias para poder dividir en categorías los productos posteriormente
        cat_procesadores=[]
        cat_tarjetsvideo=[]
        cat_tarjetasmadre=[]
        cat_discosduros=[]
        cat_memoriasusb=[]
        cat_pantallas=[]
        cat_bocinas=[]
        cat_audifonos=[]
        contador = 0 #bandera para contar número de veces que se vende un producto

        lista_ventas = [] # lista en blanco [ventas (veces vendido), nombre, id]

        #usa el id de producto como llave entre las dos tablas (lista de producto y lista de ventas) y si son iguales, cuenta el producto.

        for nombre in lifestore_products:
          for ventas in lifestore_sales:
            if nombre [0]== ventas [1]:
              contador +=1
          agregar_producto= [contador, nombre[0], nombre [1], nombre[3]] #define como será el orden en el que se agregará el producto
          lista_ventas.append(agregar_producto) #agrega el producto a la lista
          contador=0 #resetea el contador 


          lista_ordenada= sorted(lista_ventas,reverse=True)
        for categoria in lista_ordenada:
          if categoria [3]== "procesadores":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_procesadores.append(agregar_categoria)
          elif categoria [3]== "tarjetas de video":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_tarjetsvideo.append(agregar_categoria)
          elif categoria [3]== "tarjetas madre":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_tarjetasmadre.append(agregar_categoria)
          elif categoria [3]== "discos duros":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_discosduros.append(agregar_categoria)
          elif categoria [3]== "memorias usb":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_memoriasusb.append(agregar_categoria)
          elif categoria [3]== "pantallas":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_pantallas.append(agregar_categoria)
          elif categoria [3]== "bocinas":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_bocinas.append(agregar_categoria)
          elif categoria [3]== "audifonos":
            agregar_categoria=[categoria[0],categoria[1],categoria[2], categoria[3]]
            cat_audifonos.append(agregar_categoria)
          else:
            break

        print("Categoría: audífonos")
        print(cat_audifonos[0:20],"\n")
        print("Categoría:bocinas")
        print(cat_bocinas[0:20],"\n")
        print("Categoría: discos duros")
        print(cat_discosduros[0:20],"\n")
        print("Categoría: memorias USB")
        print(cat_memoriasusb[0:20],"\n")
        print("Categoría: pantallas")
        print(cat_pantallas[0:20],"\n")
        print("Categoría: procesadores")
        print(cat_procesadores[0:20],"\n")
        print("Categoría: tarjetas madre")
        print(cat_tarjetasmadre[0:20],"\n")
        print("Categoría: tarjetas de video")
        print(cat_tarjetsvideo[0:20],"\n")
      else:
        print("Opción incorrecta")  
    elif opciones== "d":  
      """
      #50 Productos más vendidos considerando devoluciones
      """
      contador_devoluciones = 0 #bandera para contar número de veces que se vende un producto

      lista_ventas_devoluciones = [] # lista en blanco [ventas (veces vendido), nombre, id]

      #usa el id de producto como llave entre las dos tablas (lista de producto y lista de ventas) y si son iguales, cuenta el producto.

      for nombre in lifestore_products:
        for ventas in lifestore_sales:
          if nombre [0]== ventas [1] and ventas[4] ==0:
            contador_devoluciones +=1 #si el id es el mismo y las ventas no fueron devueltas, las cuenta
        agregar_producto= [contador_devoluciones, nombre[1], nombre [0], nombre [2]] #define como será el orden en el que se agregará el producto
        #ventas, nombre, id, precio
        lista_ventas_devoluciones.append(agregar_producto) #agrega el producto a la lista
        contador_devoluciones=0 #resetea el contador 

        lista_ordenada= sorted(lista_ventas_devoluciones,reverse=True)
        total_ventas=[]
      for nombre in lifestore_products:
        for totales in lista_ordenada:
          if nombre [0]== totales [2]:
            ventasint=totales[0]
            costoint=nombre[2]
            ventas_totales=(ventasint)*(costoint)
        agregar_total=[nombre[0], nombre[1], totales [0],ventas_totales]
        #id, nombre, no de venta y total ventas
        total_ventas.append(agregar_total)
        #id, nombre, no de venta y total ventas
        
      for cientos in range(0,42):
        print("Producto: \n",total_ventas[cientos][1],"\n", "$", total_ventas[cientos][3])
      

else:
    print( "Password incorrecto " +user_input,". No puedes ingresar.") 